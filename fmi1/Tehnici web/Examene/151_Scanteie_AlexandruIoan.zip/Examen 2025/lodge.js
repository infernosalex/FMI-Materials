window.addEventListener("load", main);
function main() {
    canvasElem = document.getElementById("field"); 
    ctx = canvasElem.getContext("2d");
    drawField();
}

var canvasElem;
var ctx;
function drawField(){
    canvasElem.width = 600;
    canvasElem.height = 500;

    ctx.save();

    ctx.clearRect(0, 0, canvasElem.width, canvasElem.height);

    ctx.fillStyle = "red";
    ctx.fillRect(0, 0, 600, 240);

    var img = new Image;
    img.onload = function(){
        ctx.drawImage(img, 70, 70, 180, 180);
    };
    img.src = "resources/images/rose.webp";



    // properties of zigzag lines
    var x = -16;    // offset by stroke width so the edges of of path are hidden
    var dx = 64;
    var xMax = canvasElem.width + 16;


    ctx.beginPath();
    ctx.strokeStyle = 'black';
    ctx.lineWidth = 16;
    ctx.moveTo(x, canvasElem.height * 0.6);

    while (x < xMax) {
        x += dx;
        ctx.lineTo(x, canvasElem.height * 0.5);
        x += dx;
        ctx.lineTo(x, canvasElem.height * 0.6);
    }
    ctx.stroke();

    x = 0 - 16; // offset again.

    ctx.beginPath();
    ctx.strokeStyle = 'black';
    ctx.lineWidth = 16;
    ctx.moveTo(x, canvasElem.height * 0.7);

    while (x < xMax) {
        x += dx;
        ctx.lineTo(x, canvasElem.height * 0.6);
        x += dx;
        ctx.lineTo(x, canvasElem.height * 0.7);
    }
    ctx.stroke();


    x = 0 - 16; // offset again.

    ctx.beginPath();
    ctx.strokeStyle = 'black';
    ctx.lineWidth = 16;
    ctx.moveTo(x, canvasElem.height * 0.8);

    while (x < xMax) {
        x += dx;
        ctx.lineTo(x, canvasElem.height * 0.7);
        x += dx;
        ctx.lineTo(x, canvasElem.height * 0.8);
    }
    ctx.stroke();

    x = 0 - 16; // offset again.

    ctx.beginPath();
    ctx.strokeStyle = 'black';
    ctx.lineWidth = 16;
    ctx.moveTo(x, canvasElem.height * 0.9);

    while (x < xMax) {
        x += dx;
        ctx.lineTo(x, canvasElem.height * 0.8);
        x += dx;
        ctx.lineTo(x, canvasElem.height * 0.9);
    }
    ctx.stroke();



    ctx.restore();
}



window.onload = function () {
 // modify this
    canvas = document.querySelector(`#field`)
    canvas.addEventListener("click", select);

 // modify this
    const url = `http://127.0.0.1:5500/28ianuarie/resources/quotes.json`;
    
    var promiseFetch = fetch(url);
    let list;
    let nrlist;

    promiseFetch.then((response) => {
        if (!response.ok) {
            throw new Error(`HTTP error: ${response.status}`);
        }
        return response.text();
    })
    .then(function(text) {
        list = JSON.parse(text);
        nrlist = list.length
    })
    .catch(function (err) {
        alert(err);
    });

    let divDesc = document.createElement('div')
    divDesc.className = "divDesc"
    document.body.append(divDesc)

    function select() {
        let index = Math.floor(Math.random() * nrlist)
        console.log(list[index])
        let character = list[index]["character"]
        let quote = list[index]["quote"]
        let season = list[index]["season"]
        let episode = list[index]["episode"]
        divDesc.innerHTML = 
        `
        <div class="citat">
        <strong>${character}</strong>
        <p>${quote}</p>
        </div>
        <div class="tabela">
        Sezon ${season}, episode ${episode}
        </div>
        `
    }
}


