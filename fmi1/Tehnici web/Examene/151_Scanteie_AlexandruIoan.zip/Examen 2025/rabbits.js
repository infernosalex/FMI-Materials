nrTotalIepuri = 0

if (!sessionStorage.getItem('nrTotalIepuri')) {
    sessionStorage.setItem('nrTotalIepuri', '0');
}


let contor = document.createElement('div')
contor.innerText = `Numarul total de iepuri este: ${nrTotalIepuri}`
contor.style.right='10px'
contor.style.padding = '5px'
contor.style.backgroundColor = "white"
contor.style.position="absolute"
contor.style.zIndex = 100000
document.body.append(contor)

iepuri = []

function incNrIepuri(){
    nrTotalIepuri++
    sessionStorage.setItem('nrTotalIepuri', nrTotalIepuri);
    contor.innerText = `Numarul total de iepuri este: ${nrTotalIepuri}`

}

document.body.onkeydown = (e) => {
    if(e.key === 'r'){
        let iepureNou = document.createElement('div')
        let x = Math.random() * (window.innerWidth - 200)
        let y = Math.random() * (window.innerHeight - 200)

        iepureNou.style.top = y+"px"
        iepureNou.style.left = x+"px"
        iepureNou.style.width = "200px"
        iepureNou.style.height = "200px"
        iepureNou.style.position = "absolute"
        iepureNou.style.backgroundSize = "contain"
        iepureNou.style.backgroundRepeat = "no-repeat"
        iepureNou.style.backgroundImage = "url(resources/images/rabbit-01.png)"
        iepureNou.angle = Math.random() * Math.PI
        iepuri.push(iepureNou)
        iepureNou.onclick = metamorfoza
        
        let imgIepuri = ["url(resources/images/rabbit-02.png)","url(resources/images/rabbit-03.png)"]
        
        function metamorfoza(){
            // https://stackoverflow.com/questions/7820683/convert-boolean-result-into-number-integer
            let i = +(Math.random() < 0.5)
            setTimeout(() => {
                iepureNou.style.backgroundImage = imgIepuri[i] 
            }, 200)
            setTimeout(() => {
                removeIepure(iepureNou)
            }, 400)
        }
        
        incNrIepuri()
        document.body.append(iepureNou)
    }

    if(e.key === 'p'){
        if(movingAllDirection) return
        movingAllDirection = true;
        requestAnimationFrame(moveAllDirections)
    }    
    if(e.key === 's'){
        movingAllDirection = false;
    }

    if(e.key === 'a'){
        let sunet = document.createElement('audio')
        sunet.src = "resources/rabbits-ambience.mp3"
        document.body.append(sunet)
        sunet.play()
    }
}


function removeIepure(iepure){
    var i  = iepuri.indexOf(iepure)
    if(i >= 0)
        iepuri.splice(i, 1)
    iepure.remove()
}

var lastTimestamp = -1;
var movingAllDirection = false;

function moveAllDirections(timestamp) {
    if(movingAllDirection == false){
        lastTimestamp = -1;
        return;
    }

    if(lastTimestamp == -1){
        lastTimestamp = timestamp;
    }

    var deltaTime = timestamp - lastTimestamp;

    for(let i = 0; i < iepuri.length; i++){
        var directionChangeSpeed = 50;
        iepuri[i].angle += (Math.random() * directionChangeSpeed - directionChangeSpeed / 2) * (deltaTime / 1000);

        var posX = parseFloat(iepuri[i].style.left.slice(0, -2));
        var posY = parseFloat(iepuri[i].style.top.slice(0, -2));

        var speed = 0.05;
        posX += Math.cos(iepuri[i].angle) * speed * deltaTime;
        posY += Math.sin(iepuri[i].angle) * speed * deltaTime;
        
        iepuri[i].style.top = `${posY}px`;
        iepuri[i].style.left = `${posX}px`;
    }

    lastTimestamp = timestamp;

    requestAnimationFrame(moveAllDirections)
}